#include<stdio.h>
main()
{
	int data=0;
	char var;
	if(data==0);
	return 0;
}
