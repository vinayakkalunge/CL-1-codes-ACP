#include<stdio.h>
main()
{
	int b;
	int c=2;
	int d=1;
	b=c+d;
}

